var url = "https://d3v-kodasupport.zendesk.com/api/v2/tickets/5.json";

var test = url.indexOf(".zendesk.com");

console.log(test);

var newUrl = url.substr(0, test);

console.log(newUrl + ".zendesk.com/agent/tickets/36");
