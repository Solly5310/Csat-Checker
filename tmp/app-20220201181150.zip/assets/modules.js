const fs = require("fs");
const superagent = require("superagent");
console.log(__dirname);

const readFilePro = (file) => {
  //resolve will mark the functino as successful
  return new Promise((resolve, reject) => {
    fs.readFile(file, (err, data) => {
      if (err) reject("Cant find the file");
      resolve(data);
    });
  });
};

const writeFilePro = (file, img) => {
  return new Promise((resolve, reject) => {
    fs.writeFile(file, img, (err) => {
      resolve("Yep");
      if (err) reject(console.log("Could not save file"));
    });
  });
};

const getDogPic = async () => {
  try {
    let data = await readFilePro(`./starter/dog.txt`);

    const img1 = superagent.get(
      `https://dog.ceo/api/breed/${data}/images/random`
    );

    const img2 = superagent.get(
      `https://dog.ceo/api/breed/${data}/images/random`
    );

    const img3 = superagent.get(
      `https://dog.ceo/api/breed/${data}/images/random`
    );

    const all = await Promise.all([img1, img2, img3]);

    console.log(all[0]._body.message);
    const z = all[0]._body.message;
    const result = await writeFilePro("dog-img.txt", z);
    console.log(result);
  } catch (err) {
    throw err;
  }
  return "2: READY";
};

(async () => {
  try {
    const x = await getDogPic();
    console.log(x);
  } catch (err) {
    console.log(err);
  }
})();

/*
console.log("1: yep");
getDogPic()
  .then((res) => {
    console.log(res);
  })
  .catch((err) => {
    console.log(err);
  });
console.log("2: done");
*/

/*
readFilePro(`./starter/dog.txt`)
  .then((data) => {
    console.log("The data is " + data);
    return superagent.get(`https://dog.ceo/api/breed/${data}/images/random`);
  })
  .then((res) => {
    console.log(res._body.message);
    return writeFilePro("dog-img.txt", res._body.message);
  })
  .then((res) => {
    console.log(res);
  })
  .catch((err) => {
    console.log("You got it wrong");
  });
*/
