$(function () {
  // The code here initialises the zendesk session with the app
  // There are many functions which can be applied to the client variable
  var client = ZAFClient.init();
  client.invoke("resize", { width: "100%", height: "300px" });
  startPrompt();
  //client call to get the user id for the current user
  //This is the code to receive the sentiment data
  //this code connects to the ZD API to collect ticket converstaion data
});

// First function that will initially prompt user
function startPrompt() {
  $("#test").append(
    "<h1 class='u-semibold u-fs-xl' >Welcome to the CSAT Checker</h1>"
  );
}

//event listener for the form submit
const form = document.getElementById("form");
form.addEventListener("submit", (event) => {
  event.preventDefault();
  var date = document.getElementById("start").value;
  $("#form").remove();
  $("#test").append(`<p>The date chosen was ${date}</p>`);
  checkTickets(date);
});

function checkTickets(date) {
  var client = ZAFClient.init();
  var compareDate = new Date(date);
  //initial scan of first 1000 available tickets (can revise)
  client.request(
    //insert audit ticket request).then(
    function (tickets) {
      //Function to call the apis for the ticket, still dont know how to work single threading when making multiple api calls, will need to look at again
      /*
      ticket_list = [];

      tic = tickets.audits;
      console.log(tickets.audits);

      for (x in tic) {
        //ticket id for each ticket being checked
        tID = tic[x].ticket_id;

        //creation date for the ticket
        tCreatedDate = new Date(tic[x].created_at);

        //If date submitted is prior to the ticket creation date
        if (compareDate.getTime() < tCreatedDate.getTime()) {
          ticket_list.push(tID);
        }
      }
      console.log(ticket_list);
      //get rid of any duplicates in ticket ids
      ticket_list = removeDuplicates(ticket_list);
      for (x in ticket_list) {
        ticketAnalysis(ticket_list[x]);
      }*/
    },
    function (response) {
      console.error(response.responseText);
    }
  );
}

const obtainCustomerInfo = (user) => {
  var client = ZAFClient.init();
  //resolve will mark the functino as successful
  return new Promise((resolve, reject) => {
    client.request(`/api/v2/users/${user}.json`).then((data) => {
      resolve(data);
    });
  });
};

async function ticketAnalysis(tID) {
  var client = ZAFClient.init();
  client.request(`/api/v2/tickets/${tID}/comments`).then(
    function (tickets) {
      console.log(tickets);
      for (x in tickets.comments) {
        console.log(tickets.comments[x].author_id);
      }
      obtainCustomerInfo(tickets.comments[x].author_id).then((data) => {
        console.log(data);
      });
    },
    function (response) {
      console.error(response.responseText);
    }
  );

  /*
  client.request(`/api/v2/tickets/${tID}/comments`).then(
    function (tickets) {
      console.log(tickets);

      
    },
    function (response) {
      console.error(response.responseText);
    }
  );
  */
}

//Show hide demonstration
$(document).ready(function () {
  $("#hide").click(function () {
    $("#form").hide();
  });
  $("#show").click(function () {
    $("#form").show();
  });
});
//remove duplicates function
function removeDuplicates(data) {
  return [...new Set(data)];
}

/*
  client.request({
    url: "/api/v2/tickets.json",
    type: "POST",
    contentType: "application/json",
    data: JSON.stringify({
      ticket: {
        subject: "Test ticket #3000",
        comment: { body: "This is a test ticket" },
      },
    }),
  });
  */
