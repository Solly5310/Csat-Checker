# CSAT CHECKER

This app provides a search bar for tickets, automatically checking customer sentiment in each of them.

### The following information is displayed:

- Ticket Subject
- Ticket Sentiment Score
- Ticket Link

### Notes

- Current app is a very minimal prototype further progress to be made in the future (shown in issues section)
